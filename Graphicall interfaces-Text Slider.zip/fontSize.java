//********************************************************************
//  Uses Javafx slider to change the size of the text font
//  fontSize.java                   COMP 1231
//  Assignment 5:                Graphical User Interfaces-2
//  James Owen                   T00704318
//********************************************************************
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.beans.binding.Bindings;

public class fontSize extends Application{
  //Initiate slider and text
 private Slider fontSlider;
 private Text phraseSize;
 
 public void start(Stage primaryStage){
   //font slider settings include size, tick marks and, padding insets
   fontSlider = new Slider(1, 50, 5);
   fontSlider.setShowTickMarks(true);
   fontSlider.setPadding(new Insets(20, 0, 0, 30));
   
   //phrase that will be used
   phraseSize = new Text("Set the font Size");
   
   //increasing and decreasing font size
   phraseSize.styleProperty().bind(Bindings.format("-fx-font-size: %.2fpt;", fontSlider.valueProperty()));
   
   //setting border pane
   BorderPane pane = new BorderPane();
   pane.setBottom(fontSlider);
   pane.setCenter(phraseSize);
   
   //setting up a new scene with sizing, title 
   Scene scene = new Scene(pane, 500, 300);
    primaryStage.setTitle("Font Size");
    primaryStage.setScene(scene);
    primaryStage.show();
 }
 //main method to run the program
 public static void main(String[] args) {

        launch(args);

    }
}