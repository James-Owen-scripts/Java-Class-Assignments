//********************************************************************
//  Cube.java       COMP 1231
//  Assignment 1: Inheritance
//  James Owen              T00704318
//********************************************************************

public class Cube extends Shape3d {

      //declaring variables
  private double Side;
 
      //method that takes in the variables for area and volume and refrence to parent class   
  public Cube(double Side){
     
     super(Side*Side*Side, 6*Side*Side, "Cube");
     
     this.Side=Side;
    }
   
   //setter method    
  public void setSide(double Side){
   this.Side=Side;
  }
  
    //getter method
  public double getSide(){
   return Side; 
  }
  
  public String toString(){
    return super.toString() + " Side = " + Side;
  }
}
