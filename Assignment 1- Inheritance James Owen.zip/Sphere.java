//********************************************************************
//  Sphere.java       COMP 1231
//  Assignment 1: Inheritance
//  James Owen              T00704318
//********************************************************************

public class Sphere extends Shape3d {
  
      //declaring variables
 private double radius;

     //method that takes in the variables for area and volume and refrence to parent class        
 public Sphere(double radius){
     
     super((4*(Math.PI)*radius*radius*radius)/3, (4*(Math.PI)*radius*radius), "Sphere");
     
     this.radius=radius;
    }
   
   //setter method
  public void setRadius(double radius){
   this.radius=radius;
  }
  
    //getter method
  public double getRadius(){
   return radius; 
  }
  
  public String toString(){
    return super.toString() + " Radius = " + radius;
  }
   
}
