//********************************************************************
//  shapesTested.java       COMP 1231
//  Assignment 1: Inheritance
//  James Owen              T00704318
//********************************************************************

public class shapesTested {

public static void main(String[] args) {

//Calling parent method and child methods
Shape3d shape[]={new Cube(3),new Cylinder(6.7,4),new Sphere(3.6)};

//for loop connected to array to print out calculations
 for(int i=0;i<shape.length;i++){
  System.out.println(shape[i]);
  }

 }

}