//********************************************************************
//  Cylinder.java       COMP 1231
//  Assignment 1: Inheritance
//  James Owen              T00704318
//********************************************************************

public class Cylinder extends Shape3d {
  
      //declaring variables  
  private double radius;
  private double height;
  
     //method that takes in the variables for area and volume and refrence to parent class  
  public Cylinder(double radius, double height){
     
     super((height*(Math.PI)*radius*radius), ((2*Math.PI*radius*height)+2*Math.PI*radius*radius), "Sphere");
     
     this.radius=radius;
     this.height=height;
    }
   
   //setter methods
  public void setRadius(double radius){
   this.radius=radius;
  }
  
  public void setHeight(double height){
   this.height=height;
  }
  
  //getter methods
  public double getRadius(){
   return radius; 
  }
  
  public double getHeight(){
   return height; 
  }
  
  public String toString(){
    return super.toString() + " Radius = " + radius + " Height = " + height;
  }
   

}
