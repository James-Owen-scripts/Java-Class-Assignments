//********************************************************************
//  Shape3d.java       COMP 1231
//  Assignment 1: Inheritance
//  James Owen              T00704318
//********************************************************************

import java.text.DecimalFormat;

public class Shape3d {
  
//Declaring variables
  private double volume;
  private double area;
  private String shapeName;
  
  //protected  to be writen by sublclasses
  protected Shape3d(double volume,double area, String shapeName){
  this.volume=volume;
  this.area=area;
  this.shapeName=shapeName;
  }
  public String toString(){
    DecimalFormat dec = new DecimalFormat("#.##");
    return "The shape is a: " + shapeName + " Volume = " + dec.format(volume) + " Area = " + dec.format(area);
  }
}
