//********************************************************************
//  Parade allows clowns to do different functions within the parade
//  Parade.java                  COMP 1231
//  Assignment 4:                Introduction to Collections-Stacks-1
//  James Owen                   T00704318
//********************************************************************

// Importing Arraylist to store clowns
import java.util.ArrayList;

public class Parade {


  // Establishing array list
  private ArrayList<Clown> clownsList = new ArrayList<Clown>();
  
  // join Parade adds clowns to array list
  public void joinParade(Clown clownName){
    
    clownsList.add(clownName);
    
  }
  
  //method that removes a Clown from the Parade
  public void leaveParade(){
    
    clownsList.remove(0);
    
  }
  // Checking which clown is in front
  public boolean isFront(Clown front){
    // if statment checks if clown is in front
    if(front==clownsList.get(0))
      return true;
    // else statement returns false when clown isn't front
    else
      return false;
  }
  // toString returns the clowns in the parade
  public String toString() {
    
    String clowns = "";
    
    //loops until all clowns are printed out 
    for(Clown clown: clownsList){
      
      clowns +=clown.getName() + " ";
    }
    return clowns;
    
  }

}