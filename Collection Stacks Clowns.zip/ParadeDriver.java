//********************************************************************
//  Clown establishes clowns that can enter the parade
//  ParadeDriver.java            COMP 1231
//  Assignment 4:                Introduction to Collections-Stacks-1
//  James Owen                   T00704318
//********************************************************************

public class ParadeDriver {

  public static void main(String[] args) {
    
    //create a parade object
    Parade parade = new Parade();
    
    //creating new clowns
    Clown Phil = new Clown("Phil");
    Clown Barry = new Clown("Barry");
    Clown Ryan = new Clown("Ryan");
    Clown Lucas = new Clown("Lucas");
    
    //adding clowns to parade
    parade.joinParade(Phil);
    parade.joinParade(Barry);
    parade.joinParade(Ryan);
    parade.joinParade(Lucas);
    
    //printing out clowns
    System.out.println(parade.toString());
    //seeing which clown is at the front
    System.out.println(parade.isFront(Phil));
    System.out.println(parade.isFront(Ryan));
    
    parade.leaveParade();
    
    //seeing which clowns are still in parade
    System.out.println(parade.toString());
    
    //finding which clowns are in front
    System.out.println(parade.isFront(Phil));
    System.out.println(parade.isFront(Ryan));
    System.out.println(parade.isFront(Barry));
    
    //all clowns leave parade and printing to see if any are still there
    parade.leaveParade();
    parade.leaveParade();
    parade.leaveParade();
    System.out.println(parade.toString());
    
  }

}