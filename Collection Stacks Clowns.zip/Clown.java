//********************************************************************
//  Clown establishes clowns that can enter the parade
//  Clown.java                   COMP 1231
//  Assignment 4:                Introduction to Collections-Stacks-1
//  James Owen                   T00704318
//********************************************************************
public class Clown {

  //member variable to identify the clown
  private String name;
  
  //creates the clown name
  public Clown(String clownName){
    
    name = clownName;
    
  }
  //getName returns the clown name
  public String getName(){
    return name; 
  }
}