//********************************************************************
//  scans for integers takes average. if a non integer is entered that
//  isn't stop an exception will accure
//  AverageCalculator.java       COMP 1231
//  Assignment 3:                Exceptions
//  James Owen                   T00704318
//********************************************************************

//Java.util.* for Scanner and try catch
import java.util.*;
public class AverageCalculator {
  
  
  public static void main(String[] args) { 
    // Establishing scanner and data types
    Scanner scan = new Scanner(System.in);
    String number;
    float sum = 0, count =0;
    boolean averageCalculator = true;
    
    //while loop to run while averageCalculator is true
    while(averageCalculator == true){
      // Scanning for Sting
      number = scan.nextLine();
      
      // if statement to check if stop is entered 
      if(number.equals("stop")){
        averageCalculator=false;}
      
      // else statement that runs when stop isn't entered
      else{
        //Try statement trys to calculate avererage when an integer is entered
        try{
          int value=Integer.parseInt(number); 
          sum = sum + value;
          count++;
          System.out.println("Your average is: " + sum/count);
        }
        //catch statement runs the error when the conditions for the try and if statement are'nt met
        catch(NumberFormatException e){
          System.out.println("what was presented was not an integer");
        }
      }
    }
  }
 }

