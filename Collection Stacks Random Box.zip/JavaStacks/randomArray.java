//********************************************************************
//  Interface for Box.java
//  randomArray.java             COMP 1231
//  Assignment 4:                Introduction to Collections-Stacks-2
//  James Owen                   T00704318
//********************************************************************
package JavaStacks;

public interface randomArray<T> {

  // construction for adding item to the array
  public void add(T item);

  // construction for seeing if array is empty
  public boolean isEmpty();

  // construction for drawing item from array
  public T drawItem();

  // construction seeing current items in array
  public String toString();

}