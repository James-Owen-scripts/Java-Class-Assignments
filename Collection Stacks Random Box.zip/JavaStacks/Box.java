//********************************************************************
//  Code Randomly draws from a list 
//  Box.java                     COMP 1231
//  Assignment 4:                Introduction to Collections-Stacks-2
//  James Owen                   T00704318
//********************************************************************

package JavaStacks;

import java.util.*;

// Initiating Array class
public class Box<T> implements randomArray<T> {

  // Initiating data types
  private final static int defaultCap = 5;
  private T[] Items;
  private int itemCount;
  private int initialCap;

  public Box() {
    this(defaultCap);
  }

  // initializing the item count and Capacity of array
  public Box(int initialCap) {
    this.initialCap = initialCap;
    itemCount = 0;
    Items = (T[]) (new Object[initialCap]);

  }

  // adding items to array if more items are added then length expandCap() is
  // called
  public void add(T item) {
    if (itemCount == Items.length)
      expandCap();
    Items[itemCount] = item;
    itemCount++;
  }

  // Adds one extra item to the end of the array
  private void expandCap() {
    Items = Arrays.copyOf(Items, Items.length + 1);
  }

  // Checks if array is empty
  public boolean isEmpty() {
    if (itemCount == 0)
      return true;
    else
      return false;

  }

  // Draws item from the box but only when there is items to draw
  public T drawItem() {
    if (isEmpty()) {
      System.out.println("There is currently no items to draw from");
      return null;
    } else {
      Random rand = new Random();
      int item = rand.nextInt(itemCount);
      T Draw = Items[item];
      Items[item] = null;

      if (item < (itemCount - 1)) {
        for (int i = 0; i < ((itemCount - 1) - item); i++) {
          Items[item + i] = Items[item + i + 1];
        }
      }
      itemCount--;
      return Draw;
    }
  }

  // Returns items in the array
  public String toString() {
    String object = "";
    if (itemCount != 0) {
      for (T boxItems : Items)
        object += boxItems + ", ";
      return object;
    } else {
      return "There is currently no items in array to show";
    }
  }
}