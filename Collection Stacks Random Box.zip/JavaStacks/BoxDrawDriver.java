//********************************************************************
//  code is used as the driver to add and pull random items from a box 
//  BoxDrawDriver.java                     COMP 1231
//  Assignment 4:                Introduction to Collections-Stacks-2
//  James Owen                   T00704318
//********************************************************************

package JavaStacks;

public class BoxDrawDriver {

  public static void main(String[] args) {
    // Creating to new arrays
    Box<Integer> obj1 = new Box<Integer>(5);
    Box<String> obj2 = new Box<String>(5);

    // Showing what will hapen when there is nothing in the array
    System.out.println(obj1.drawItem());
    System.out.println(obj1.toString());
    System.out.println(obj1.isEmpty());

    // Adding numbers to first array
    obj1.add(1);
    obj1.add(2);
    obj1.add(3);
    obj1.add(4);
    obj1.add(5);

    // Showing items in first array and if it is still empty
    System.out.println(obj1.toString());
    System.out.println(obj1.isEmpty());

    // Adding names to second array
    obj2.add("Phil");
    obj2.add("Ryan");
    obj2.add("Lucas");
    obj2.add("Emerson");
    obj2.add("Matteo");

    // Showing items in the second array
    System.out.println(obj2.toString());
    System.out.println();

    // for shows which table each person will sit at
    for (int i = 0; i < 5; i++) {
      System.out.println(obj2.drawItem() + " will sit at table: " + obj1.drawItem());

    }

    // adding more items than original set capacity
    obj1.add(1);
    obj1.add(2);
    obj1.add(3);
    obj1.add(4);
    obj1.add(5);
    obj1.add(6);

    // checking items to see if all where added even though capacity has been
    // exceeded
    System.out.println();
    System.out.println(obj1.toString());
    System.out.println(obj1.isEmpty());
  }

}
