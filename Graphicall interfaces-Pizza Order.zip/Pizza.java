//********************************************************************
//  Uses Javafx to create a pizza order that cusomizes toppings
//  Pizza.java                   COMP 1231
//  Assignment 5:                Graphical User Interfaces-1
//  James Owen                   T00704318
//********************************************************************
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Pizza extends Application {
    // declaring Checkboxes
    private CheckBox extraCheese = new CheckBox("Extra Cheese");
    private CheckBox greenPepper = new CheckBox("Green Pepper");
    private CheckBox pepperoni = new CheckBox("Pepperoni");
    private CheckBox onion = new CheckBox("Onion");
    private CheckBox sausage = new CheckBox("Sausage");
    private CheckBox anchovies = new CheckBox("Anchovies");
    private Text pizzaprice = new Text("Pizza Cost: $10.00");

    public void start(Stage stage) {

        // new grid pane
        GridPane pizzaPane = new GridPane();

        // Setting gaps to 4
        pizzaPane.setHgap(4);
        pizzaPane.setVgap(4);

        pizzaPane.setAlignment(Pos.CENTER);

        // Updating cost by sending to added cost
        extraCheese.setOnAction(e -> addedCost());
        greenPepper.setOnAction(e -> addedCost());
        pepperoni.setOnAction(e -> addedCost());
        onion.setOnAction(e -> addedCost());
        sausage.setOnAction(e -> addedCost());
        anchovies.setOnAction(e -> addedCost());

        // Adding items to pane
        pizzaPane.add(extraCheese, 0, 0);
        pizzaPane.add(pepperoni, 0, 2);
        pizzaPane.add(sausage, 0, 4);
        pizzaPane.add(greenPepper, 2, 0);
        pizzaPane.add(onion, 2, 2);
        pizzaPane.add(anchovies, 2, 4);
        pizzaPane.add(pizzaprice, 0, 6, 4, 1);

        // Alignment to center
        GridPane.setHalignment(pizzaprice, HPos.CENTER);
        // Insets set to 10
        GridPane.setMargin(pizzaprice, new Insets(4));

        // Background to cornsilk
        pizzaPane.setStyle("-fx-background-color: cornsilk;");

        // Creating the scene
        Scene scene = new Scene(pizzaPane, 400, 200);
        stage.setScene(scene);
        stage.setTitle("Pizza Cost");
        stage.show();
    }

    // Method for when checkboxes are checked or unchecked
    private void addedCost() {
        double cost = 10.00;
        // if statements see if a checkbox is checked then updates the price
        if (extraCheese.isSelected()) {
            cost += 0.50;
        }
        if (greenPepper.isSelected()) {
            cost += 0.50;
        }
        if (pepperoni.isSelected()) {
            cost += 0.50;
        }
        if (onion.isSelected()) {
            cost += 0.50;
        }
        if (sausage.isSelected()) {
            cost += 0.50;
        }
        if (anchovies.isSelected()) {
            cost += 0.50;
        }
        // updating the output text
        pizzaprice.setText("Pizza Cost: $" + String.format("%.2f", cost));
    }

    // method to run the program
    public static void main(String[] args) {
        launch(args);
    }
}