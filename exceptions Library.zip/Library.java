//********************************************************************
//  Finds dublicate book titles from a file then makes a new file 
//  printing the books without the repeats
//  AverageCalculator.java       COMP 1231
//  Assignment 3:                Exceptions
//  James Owen                   T00704318
//********************************************************************

import java.io.*;

public class Library {
    public static void main(String args[]) throws IOException {
      
        // reader reads all the lines from read file
        String reader;
        
        
        //PrintWriter to set up the file and directory to be printed to
        PrintWriter prntWrt = new PrintWriter("C:\\school\\3rd times the charm\\Semester 1\\Comp 1231\\exceptions\\my code\\Dublicatetitles.out");
        
        // Buffered reader set up to read from directory
        BufferedReader bufRead = new BufferedReader(new FileReader("C:\\school\\3rd times the charm\\Semester 1\\Comp 1231\\exceptions\\my code\\BookTitles.inp"));
        
        reader = bufRead.readLine();
        
        // Loop to read all lines from the read file
        while (reader != null) {
            boolean duplicate = false;
           // second reader to read lines and see if one already exists
            BufferedReader bufRead2 = new BufferedReader(new FileReader("C:\\school\\3rd times the charm\\Semester 1\\Comp 1231\\exceptions\\my code\\Dublicatetitles.out"));

            String dupLine;
            dupLine = bufRead2.readLine();
            // Loop to get all lines from the read file
            while (dupLine != null) {
                //
                if (reader.equals(dupLine)) {
                    duplicate = true; 
                    break;
                }
                //File lines don't match both are sent to the write file
                dupLine = bufRead2.readLine();
            }
            // when dublicate is false bookTitles.inp go to duplicateTitles.out
            if (duplicate == false) {
                prntWrt.println(reader);
                prntWrt.flush();
            }

            reader =  bufRead.readLine();

        }
        // close the files
        bufRead.close();
        prntWrt.close();

        System.out.println("Duplicate titles have been stored in duplicateTitles.out without repeat lines");
    }
}