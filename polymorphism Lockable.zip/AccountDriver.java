//********************************************************************
//  Demonstrates Account.java being lockable
//  AccountDriver.java       COMP 1231
//  Assignment 2: Polymorphism-2
//  James Owen              T00704318
//********************************************************************
public class AccountDriver {
  
  
  public static void main(String[] args) { 
    System.out.println();
    System.out.println("Testing the Account");
    
    Account acct1 = new Account("Ted Murphy", 72354, 25.59);
    Account acct2 = new Account("Angelica Adams", 69713, 500.00);
    Account acct3 = new Account("Edward Demsey", 93757, 769.32);
    
    // trying different passwords and using bits of code from the account driver example
    acct1.setKey(2);
    acct2.setKey(4);
    acct3.setKey(6);
    
    acct1.unlock(2);
    acct2.unlock(2);
    acct3.lock(6);
    
    acct1.deposit (44.10); // return value ignored
    double adamsBalance = acct2.deposit (75.25);
    System.out.println("Adams balance after deposit: " +
                       adamsBalance);
    System.out.println("Adams balance after withdrawal: " +
                       acct2.withdraw (480, 1.50));
    acct3.withdraw(-100.00, 1.50); // invalid transaction
    acct1.addInterest();
    acct2.addInterest();
    acct3.addInterest();
    System.out.println();
    System.out.println(acct1);
    System.out.println(acct2);
    System.out.println(acct3);
    
    
    acct1.lock(2);
    acct2.lock(4);
    acct3.unlock(6);
    
    //Second Test
    System.out.println();
    System.out.println("Testing the Account unlocked");
    
    acct1.deposit (44.10); // return value ignored
    acct2.deposit (75.25);
    System.out.println("Adams balance after deposit: " +
                       adamsBalance);
    System.out.println("Adams balance after withdrawal: " +
                       acct2.withdraw (480, 1.50));
    acct3.withdraw(-100.00, 1.50); // invalid transaction
    acct1.addInterest();
    acct2.addInterest();
    acct3.addInterest();
    System.out.println();
    System.out.println(acct1);
    System.out.println(acct2);
    System.out.println(acct3);
  }
  
}
