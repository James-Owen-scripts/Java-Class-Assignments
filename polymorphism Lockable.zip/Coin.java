//*********************************************************************
// Coin.java Java Foundations
//
// Represents a coin with two sides that can be flipped.
//********************************************************************
// edited to be lockable
//  Lockable.java       COMP 1231
//  Assignment 2: Polymorphism-2
//  James Owen              T00704318
//********************************************************************
public class Coin implements Lockable{
  
  //Using code from the Coin example
  private final int HEADS = 0; // tails is 1
  private int face; // current side showing
  
  private int key;
  private boolean lock = false;
  
  
  public Coin()
  {
    flip();
  }
  //Set key sets the key integer
  public void setKey(int key){
    this.key = key;
  }
  //lock locks the system when key is entered
  public void lock(int key){
    if(this.key==key)
      lock=lockClose;
  }
  //unlock unlocks system when the key is entered
  public void unlock(int key){
    if(this.key==key)
      lock=lockOpen;
  }
  //locked returns the state of the system as a true or false (unlocked: true/locked: false)
  public boolean locked(){
    return lock; 
  }
//------------------------------------------------------------------
// Flips this coin by randomly choosing a face value.
//------------------------------------------------------------------
  public void flip(){
    if(locked())
      face = (int) (Math.random() * 2);
    
    else
      System.out.println("System is locked can not run this function");
    
  }
//------------------------------------------------------------------
// Returns true if the current face of this coin is heads.
//------------------------------------------------------------------
  public boolean isHeads()
  {
    if(locked())
      return (face == HEADS);
    else{
      System.out.println("System is locked can not run this function");
      return false;}
  }
//------------------------------------------------------------------
// Returns the current face of this coin as a string.
//------------------------------------------------------------------
  public String toString()
  {
    if (locked())
      return (face == HEADS) ? "Heads" : "Tails";
    else
      return "System is locked can not run this function";
  }
}