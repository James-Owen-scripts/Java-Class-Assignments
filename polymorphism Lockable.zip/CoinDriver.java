//********************************************************************
// Drives the lockable version of the coin flip code
//  CoinDriver.java       COMP 1231
//  Assignment 2: Polymorphism-2
//  James Owen              T00704318
//********************************************************************
public class CoinDriver{

  public static void main(String[] args){
    
    System.out.println("Testing the coin:");
    int heads = 0;
    
    Coin myCoin = new Coin();
    myCoin.setKey(4362);
    myCoin.lock(4362);
    
    System.out.println("Lets try the coin flip with the system locked:");
    System.out.println(myCoin.locked());
    System.out.println(myCoin.toString());
    
    //using code from coin example
    myCoin.flip();
    for(int i=0; i<20; i++){
      if (myCoin.isHeads())
        heads++;}
    System.out.println(heads);
    
    
    myCoin.unlock(4361);
    System.out.println();
    System.out.println("Lets put in the wrong password and see the results");
    System.out.println(myCoin.toString());
    
    myCoin.unlock(4362);
    myCoin.flip();
    System.out.println();
    System.out.println("Now lets try the coin flip with the system unlocked:");
    System.out.println(myCoin.locked());
    System.out.println(myCoin.toString());
    
    myCoin.flip();
    for(int i=0; i<20; i++){
      if (myCoin.isHeads())
        heads++;}
    System.out.println(heads);
    
    
  }
}