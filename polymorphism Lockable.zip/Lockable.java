//********************************************************************
//  Lockable Interface
//  Lockable.java       COMP 1231
//  Assignment 2: Polymorphism-2
//  James Owen              T00704318
//********************************************************************
public interface Lockable {
  //Establishing constants
  public final boolean lockClose = false;
  public final boolean lockOpen = true;
  
  //establishing sub-classes
  public void setKey(int key);
  public void lock(int key);
  public void unlock(int key);
  public boolean locked();
}
