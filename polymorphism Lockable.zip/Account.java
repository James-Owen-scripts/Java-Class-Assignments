//*********************************************************************
// Account.java Java Foundations
//
// Represents a bank account with basic services such as deposit
// and withdraw.
//********************************************************************
//  Edited to be lockable with interface Lockable.java 
//                          COMP 1231
//  Assignment 2:           Polymorphism-2
//  James Owen              T00704318
//********************************************************************
import java.text.NumberFormat;
public class Account implements Lockable{
  
  private final double RATE = 0.035; // interest rate of 3.5%
  private String name;
  private long acctNumber;
  private double balance;
//------------------------------------------------------------------
// Sets up this account with the specified owner, account number,
// and initial balance.
//------------------------------------------------------------------
  private int key;
  private boolean lock = true;
  
  
  //Set key sets the key integer
  public void setKey(int key){
    this.key = key;
  }
  //lock locks the system when key is entered
  public void lock(int key){
    if(this.key==key)
      lock=lockClose;
  }
  //unlock unlocks system when the key is entered
  public void unlock(int key){
    if(this.key==key)
      lock=lockOpen;
  }
  //locked returns the state of the system as a true or false (unlocked: true/locked: false)
  public boolean locked(){
    return lock; 
  }
  public Account(String owner, long account, double initial)
  {
    if (locked()){
      name = owner;
      acctNumber = account;
      balance = initial;
    }
    else
      System.out.println("System is locked can not run this function");
  }
//------------------------------------------------------------------
// Deposits the specified amount into this account and returns
// the new balance. The balance is not modified if the deposit
// amount is invalid.
//------------------------------------------------------------------
  public double deposit(double amount)
  {
    if (locked()){
      if (amount > 0)
        balance = balance + amount;
      return balance;}
    else{
      System.out.println("System is locked can not run this function");
      return 0.0;}
  }
//-----------------------------------------------------------------
// Withdraws the specified amount and fee from this account and
// returns the new balance. The balance is not modified if the
// withdraw amount is invalid or the balance is insufficient.
//-----------------------------------------------------------------
  public double withdraw(double amount, double fee)
  {
    if (locked()){
      if (amount+fee > 0 && amount+fee < balance)
        balance = balance - amount - fee;
      return balance;}
    else{
      System.out.println("System is locked can not run this function");
      return 0.0;}
  }
//-----------------------------------------------------------------
// Adds interest to this account and returns the new balance.
//-----------------------------------------------------------------
  public double addInterest()
  {
    if (locked()){
      balance += (balance * RATE);
      return balance;}
    else{
      System.out.println("System is locked can not run this function");
      return 0.0;}
  }
//-----------------------------------------------------------------
// Returns the current balance of this account.
//-----------------------------------------------------------------
  public double getBalance()
  {
    if (locked())
      return balance;
    else{
      System.out.println("System is locked can not run this function");
      return 0.0;}
  }
//-----------------------------------------------------------------
// Returns a one-line description of this account as a string.
//-----------------------------------------------------------------
  public String toString()
  {
    if (locked()){
      NumberFormat fmt = NumberFormat.getCurrencyInstance();
      return (acctNumber + "\t" + name + "\t" + fmt.format(balance));}
    else
      return"System is locked can not run this function";
  }
}