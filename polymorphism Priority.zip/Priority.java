//********************************************************************
// Interface for Task.Java
//  Priority.java       COMP 1231
//  Assignment 2:       Polymorphism-1
//  James Owen          T00704318
//********************************************************************

public interface Priority {
  //Low priority will be between 1 and 5
   public static final int LOW = 1;
   //meduim priority will be between 6 and 10
   public static final int MEDIUM = 6;
   //meduim priority will be between 11 and 15
   public static final int HIGH = 11;
  
  public void setPriority(int Priority);
  public int getPriority();
  
}
