//********************************************************************
// Driver for tasks priority
//  TaskDriver.java       COMP 1231
//  Assignment 2: Polymorphism-1
//  James Owen              T00704318
//********************************************************************

public class TaskDriver {
  public static void main(String[] args) {
    
    //Calling the Task and creating 5 seperate tasks
    Task Task1 = new Task("Dishes", 12);
    Task Task2 = new Task("Garbage", 8);
    Task Task3 = new Task("Dishes", 3);
    Task Task4 = new Task("Cleaning", 5);
    Task Task5 = new Task("Groceries", -2);
    
    System.out.println("Priority Values:");
    //Loop prints Tasks in order of priority level
    for(int i = 15; i>0;i--){
      
      if(Task1.getPriority() == i)
        System.out.println(Task1);
      if(Task2.getPriority() == i)
        System.out.println(Task2);
      if(Task3.getPriority() == i)
        System.out.println(Task3);
      if(Task4.getPriority() == i)
        System.out.println(Task4);
      if(Task5.getPriority() == i)
        System.out.println(Task5);
    }
    
    //Setting new Priority Values
    Task1.setPriority(7);
    Task2.setPriority(7);
    Task3.setPriority(17);
    Task4.setPriority(3);
    Task5.setPriority(3);
    
    System.out.println();
    System.out.println("New Priority Values:");
    
    //Loop prints Tasks in order of priority level
    for(int i = 15; i>0;i--){
      
      if(Task1.getPriority() == i)
        System.out.println(Task1);
      if(Task2.getPriority() == i)
        System.out.println(Task2);
      if(Task3.getPriority() == i)
        System.out.println(Task3);
      if(Task4.getPriority() == i)
        System.out.println(Task4);
      if(Task5.getPriority() == i)
        System.out.println(Task5);
    }
    
    System.out.println();
    System.out.println("Get examples:");
    System.out.println(Task1.getPriority());
    System.out.println(Task1.getToDos());
  }
}