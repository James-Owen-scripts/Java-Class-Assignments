//********************************************************************
// Ranks tasks by priority
//  Task.java       COMP 1231
//  Assignment 2: Polymorphism-1
//  James Owen              T00704318
//********************************************************************

public class Task implements Priority {
  //Setting the data types for each task
  private int priority;
  private String toDos;
  private String Level;
  
  public Task(String toDos, int priority)
   {
       this.toDos = toDos;
      
       this.priority = priority;
       // validate priority is not less than LOW if it is set priority to LOW
       if(this.priority < LOW)
           this.priority = LOW;
       // validate priority is not greater than HIGH if it is set priority to HIGH
       else if(this.priority > 15)
           this.priority = 15;
       
       //Setting each priority level
       if(this.priority >= LOW && this.priority < MEDIUM)
         Level = "Low";
       if(this.priority >= MEDIUM && this.priority < HIGH)
         Level = "Medium";
       if(this.priority >= HIGH)
         Level = "High";
   }
  public void setPriority(int priority) {
       this.priority = priority;
       // validate priority is not less than LOW if it is set priority to LOW
       if(this.priority < LOW)
           this.priority = LOW;
       // validate priority is not greater than HIGH if it is set priority to HIGH
       else if(this.priority > 15)
           this.priority = 15;
       
       //Setting each priority level
       if(this.priority >= LOW && this.priority < MEDIUM)
         Level = "Low";
       if(this.priority >= MEDIUM && this.priority < HIGH)
         Level = "Medium";
       if(this.priority >= HIGH)
         Level = "High";
}
   public int getPriority() {
       return priority;
   }
 
   // method ot return the description of the task
   public String getToDos()
   {
       return toDos;
   }
     public String toString()
   {
       return "Task: " + toDos + " Priority: "+ priority + " Level: " + Level;
   }
}